`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/14/2026 09:11:57 PM
// Design Name: 
// Module Name: fir_filter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fir_filter_tb;

    localparam int NUM_TAPS   = 73;
    localparam int IN_WIDTH   = 12;
    localparam int OUT_WIDTH  = 16;
    localparam int CLK_PERIOD = 10;      // 100 MHz
    localparam int SAMPLE_CYCLES = 50;   // 500 ns / 10 ns  -> 2 MSps budget

    real h [0:NUM_TAPS-1];
    initial begin
        h[ 0]=0.025804122; h[ 1]=0.020552684; h[ 2]=0.028396631; h[ 3]=0.037923047;
        h[ 4]=0.049296639; h[ 5]=0.062671826; h[ 6]=0.078188509; h[ 7]=0.095967794;
        h[ 8]=0.116107786; h[ 9]=0.138679546; h[10]=0.163723333; h[11]=0.191245225;
        h[12]=0.221214225; h[13]=0.253559961; h[14]=0.288171034; h[15]=0.324894126;
        h[16]=0.363533898; h[17]=0.403853725; h[18]=0.445577304; h[19]=0.488391123;
        h[20]=0.53194777;  h[21]=0.575870065; h[22]=0.61975593;  h[23]=0.663183933;
        h[24]=0.705719403; h[25]=0.746921012; h[26]=0.786347677; h[27]=0.82356567;
        h[28]=0.858155769; h[29]=0.889720317; h[30]=0.917890027; h[31]=0.942330394;
        h[32]=0.962747575; h[33]=0.978893597; h[34]=0.990570797; h[35]=0.997635377;
        h[36]=1.0;
        h[37]=0.997635377; h[38]=0.990570797; h[39]=0.978893597; h[40]=0.962747575;
        h[41]=0.942330394; h[42]=0.917890027; h[43]=0.889720317; h[44]=0.858155769;
        h[45]=0.82356567;  h[46]=0.786347677; h[47]=0.746921012; h[48]=0.705719403;
        h[49]=0.663183933; h[50]=0.61975593;  h[51]=0.575870065; h[52]=0.53194777;
        h[53]=0.488391123; h[54]=0.445577304; h[55]=0.403853725; h[56]=0.363533898;
        h[57]=0.324894126; h[58]=0.288171034; h[59]=0.253559961; h[60]=0.221214225;
        h[61]=0.191245225; h[62]=0.163723333; h[63]=0.138679546; h[64]=0.116107786;
        h[65]=0.095967794; h[66]=0.078188509; h[67]=0.062671826; h[68]=0.049296639;
        h[69]=0.037923047; h[70]=0.028396631; h[71]=0.020552684; h[72]=0.025804122;
    end

    logic clk = 0, reset = 0;
    logic in_valid;
    logic signed [IN_WIDTH-1:0]  data_in;
    logic out_valid;
    logic signed [OUT_WIDTH-1:0] data_out;

    real x_real [0:99];
    logic signed [IN_WIDTH-1:0] x_fixed [0:99];

    int out_count = 0;
    int errors = 0;

    fir_filter #(
        .NUM_TAPS(NUM_TAPS), .IN_WIDTH(IN_WIDTH), .OUT_WIDTH(OUT_WIDTH)
    ) dut (
        .clk(clk), .reset(reset),
        .in_valid(in_valid), .data_in(data_in),
        .out_valid(out_valid), .data_out(data_out)
    );

    always #(CLK_PERIOD/2) clk = ~clk;

    initial begin
        x_real[0] = 1.0;   // impulse -> first outputs trace h[] directly
        for (int i = 1; i < 100; i++)
            x_real[i] = 0.3*$sin(2.0*3.14159265*i/17.0);

        for (int i = 0; i < 100; i++)
            x_fixed[i] = $rtoi($floor(x_real[i]*1024.0 + 0.5));
    end

    function automatic real golden_fir(int sample_idx);
        real acc;
        acc = 0.0;
        for (int k = 0; k < NUM_TAPS; k++) begin
            int idx = sample_idx - k;
            if (idx >= 0)
                acc += h[k] * x_real[idx];
        end
        return acc;
    endfunction

    task automatic send_sample(int idx);
        @(posedge clk);
        data_in  <= x_fixed[idx];
        in_valid <= 1'b1;
        @(posedge clk);
        in_valid <= 1'b0;
    endtask

    real expected, got, diff;
    always @(posedge clk) begin
        if (out_valid) begin
            expected = golden_fir(out_count);
            got      = $itor(data_out) / 8192.0;   // Q3.13 -> real
            diff     = expected - got;
            if (diff < 0) diff = -diff;

            if (diff > 0.01) begin
                errors++;
                $display("[%0t] MISMATCH sample %0d: expected=%f got=%f diff=%f",
                          $time, out_count, expected, got, diff);
            end else
                $display("[%0t] OK       sample %0d: expected=%f got=%f",
                          $time, out_count, expected, got);

            out_count++;
        end
    end

    initial begin
        in_valid = 0;
        data_in  = '0;
        repeat (5) @(posedge clk);
        reset = 1;
        repeat (5) @(posedge clk);

        for (int i = 0; i < 100; i++) begin
            send_sample(i);
            repeat (SAMPLE_CYCLES - 2) @(posedge clk);
        end

        repeat (SAMPLE_CYCLES) @(posedge clk);

        if (errors == 0)
            $display("\n*** TEST PASSED: all %0d samples matched golden model (2 MSps timing) ***\n", out_count);
        else
            $display("\n*** TEST FAILED: %0d mismatches out of %0d samples ***\n", errors, out_count);

        $finish;
    end

endmodule